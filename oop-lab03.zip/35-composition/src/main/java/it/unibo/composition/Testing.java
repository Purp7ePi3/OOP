package it.unibo.composition;

public class Testing {

    public static void main(final String[] args) {

        // 1)Creare 3 studenti a piacere

        // 2)Creare 2 docenti a piacere

        // 3) Creare due aulee di esame, una con 100 posti una con 80 posti

        // 4) Creare due esami, uno con nMaxStudents=10, l'altro con
        // nMaxStudents=2

        // 5) Iscrivere tutti e 3 gli studenti agli esami

        // 6) Stampare in stdout la rapresentazione in stringa dei due esami
    }
}
