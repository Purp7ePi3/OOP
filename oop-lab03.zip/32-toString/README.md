#### Il metodo `toString()`

* Analizzare `AccountHolder`
* Modella un generico utilizzatore di conto bancario, identificato da un id
* È realizzata applicando i principi di incapsulamento e information hiding
(che andranno applicati *sempre* d'ora in poi ad *ogni* classe che costruiremo).
* Si implementi il metodo `String toString()` lasciato incompleto
(si ricordi che `String toString()` è il metodo convenzionalmente usato in Java per ottenere la rappresentazione testuale di un oggetto).
